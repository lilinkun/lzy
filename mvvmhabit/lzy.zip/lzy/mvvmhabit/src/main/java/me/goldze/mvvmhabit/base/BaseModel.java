package me.goldze.mvvmhabit.base;

/**
 * Created by goldze on 2017/6/15.
 */
public class BaseModel implements IModel {

    public BaseModel() {
    }

    @Override
    public void onCleared() {

    }
}
