package me.goldze.mvvmhabit.binding.command;

/**
 * A zero-argument action.
 */

public interface BindingAction {
    void call();
}
