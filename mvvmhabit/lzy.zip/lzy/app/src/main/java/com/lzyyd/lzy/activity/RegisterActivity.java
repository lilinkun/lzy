package com.lzyyd.lzy.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.databinding.ActivityRegisterBinding;
import com.lzyyd.lzy.viewmodel.RegisterViewModel;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

public class RegisterActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityRegisterBinding registerBinding = DataBindingUtil.setContentView(this, R.layout.activity_register);

        RegisterViewModel registerViewModel = new RegisterViewModel(this,registerBinding);


        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(0,40,0,0);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        registerBinding.ivWelcome.setLayoutParams(layoutParams);
    }
}
