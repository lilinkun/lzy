package com.lzyyd.lzy.viewmodel;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.lzyyd.lzy.BR;
import com.lzyyd.lzy.activity.ForgetSettingPsdActivity;
import com.lzyyd.lzy.databinding.ActivityForgetpasswordBinding;
import com.lzyyd.lzy.model.ForgetPsdModel;

import androidx.databinding.BaseObservable;

public class ForgetPasswordViewModel extends BaseObservable {

    private ActivityForgetpasswordBinding activityForgetpasswordBinding;
    private ForgetPsdModel forgetPsdModel;
    private String mobileStr;
    private Context context;


    public ForgetPasswordViewModel(Context context,ActivityForgetpasswordBinding binding) {
        this.activityForgetpasswordBinding = binding;
        this.forgetPsdModel = new ForgetPsdModel();
        this.context = context;
    }

    public String getMobileStr() {
        return mobileStr;
    }

    public void setMobileStr(String mobileStr) {
        this.mobileStr = mobileStr;
        notifyPropertyChanged(BR.forget);
    }

    public void setNewPsd(View view){

        Intent intent = new Intent(context, ForgetSettingPsdActivity.class);
        context.startActivity(intent);

    }
}
