package com.lzyyd.lzy.viewmodel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.lzyyd.lzy.activity.GoodsDetailActivity;
import com.lzyyd.lzy.bean.SeckillGoodsBean;
import com.lzyyd.lzy.databinding.ActivitySeckillBinding;

import androidx.databinding.BaseObservable;

public class SeckillViewModel extends BaseObservable {

    public ActivitySeckillBinding activitySeckillBinding;
    public Activity activity;

    public SeckillViewModel(ActivitySeckillBinding activitySeckillBinding, Activity activity) {
        this.activitySeckillBinding = activitySeckillBinding;
        this.activity = activity;
    }

    public void setBack(){
        activity.finish();
    }

}
