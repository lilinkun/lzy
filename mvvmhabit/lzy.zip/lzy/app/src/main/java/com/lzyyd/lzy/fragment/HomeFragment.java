package com.lzyyd.lzy.fragment;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseFragment;

public class HomeFragment extends BaseFragment {



    @Override
    protected int setContentView() {
        return R.layout.fragment_home;
    }

    @Override
    protected void lazyLoad() {

    }
}
