package com.lzyyd.lzy.viewmodel;

import android.content.Context;

import com.lzyyd.lzy.bean.SeckillGoodsBean;

import androidx.databinding.BaseObservable;
import androidx.databinding.ObservableField;

public class SeckillItemViewModel extends BaseObservable {

    public ObservableField<SeckillGoodsBean> observableField = new ObservableField<>();




    SeckillItemViewModel(Context context, SeckillGoodsBean demoEntity){
        observableField.set(demoEntity);
    }

}
