package com.lzyyd.lzy.interf;

import android.view.View;

import com.lzyyd.lzy.bean.SeckillGoodsBean;

public interface SeckillItemClick {

    public void onClick(View view, SeckillGoodsBean seckillGoodsBean);

}
