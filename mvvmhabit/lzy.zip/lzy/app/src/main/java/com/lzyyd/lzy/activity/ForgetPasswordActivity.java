package com.lzyyd.lzy.activity;

import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.Window;
import android.view.WindowManager;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.databinding.ActivityForgetpasswordBinding;
import com.lzyyd.lzy.util.Eyes;
import com.lzyyd.lzy.viewmodel.ForgetPasswordViewModel;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

public class ForgetPasswordActivity extends BaseActivity {


    private ActivityForgetpasswordBinding binding;
    private ForgetPasswordViewModel passwordViewModel;
    String mobileStr;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Eyes.setStatusBarColor1(this,R.color.white);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_forgetpassword);
        passwordViewModel = new ForgetPasswordViewModel(this,binding);
        binding.setForget(passwordViewModel);
        passwordViewModel.setMobileStr("130****4561");
    }




}
