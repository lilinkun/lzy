package com.lzyyd.lzy.interf;

import com.lzyyd.lzy.bean.Account;

public interface MCallback {
    public void onSuccess(Account account);
    public  void onFailed();
}
