package com.lzyyd.lzy.interf;

import android.view.View;

import com.lzyyd.lzy.bean.User;

public interface MyHandlers {

        public void onClickFriend(User user);

}
