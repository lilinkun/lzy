package com.lzyyd.lzy.viewmodel;

import android.content.Context;

import com.lzyyd.lzy.databinding.ActivityRegisterBinding;

import androidx.databinding.BaseObservable;

public class RegisterViewModel extends BaseObservable {

    ActivityRegisterBinding activityRegisterBinding;
    Context context;
    public int statusHeight;

    public RegisterViewModel(Context context,ActivityRegisterBinding binding) {
        this.activityRegisterBinding = binding;
        this.context = context;

        //获取status_bar_height资源的ID
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            //根据资源ID获取响应的尺寸值
            statusHeight = context.getResources().getDimensionPixelSize(resourceId);
        }

    }

}
