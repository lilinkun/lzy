package com.lzyyd.lzy.viewmodel;

import android.content.Context;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.lzyyd.lzy.databinding.ActivityForgetSettingPsdBinding;
import com.lzyyd.lzy.model.ForgetSettingPsdModel;

import androidx.databinding.BaseObservable;
import androidx.databinding.BindingAdapter;
import androidx.databinding.InverseBindingListener;
import androidx.databinding.InverseBindingMethod;
import androidx.databinding.InverseBindingMethods;
import androidx.databinding.Observable;
import androidx.databinding.ObservableBoolean;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;

public class ForgetSettingPsdViewModel extends BaseObservable {

    ActivityForgetSettingPsdBinding binding;
    Context context;
    ForgetSettingPsdModel settingPsdModel;

    public ObservableBoolean observableBoolean = new ObservableBoolean();
    public ObservableInt observableInt = new ObservableInt();

    public ForgetSettingPsdViewModel(Context context,ActivityForgetSettingPsdBinding binding) {
        this.binding = binding;
        this.context = context;
        settingPsdModel = new ForgetSettingPsdModel();
    }

    @BindingAdapter({"setCheckValue"})
    public static void setCheckValue(final CheckBox checkBox, final ObservableField<Boolean> tags){
        tags.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                checkBox.setChecked(tags.get());
            }
        });
    }

    public void setChecked(boolean isCheck){

        binding.etInputNewPsd.setInputType(isCheck ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
        binding.etSureNewPsd.setInputType(isCheck ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);

    }



}
