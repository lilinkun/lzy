package com.lzyyd.lzy.activity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.databinding.ActivityLoginBinding;
import com.lzyyd.lzy.util.Eyes;
import com.lzyyd.lzy.viewmodel.LoginViewModel;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

public class LoginActivity extends BaseActivity {

    ActivityLoginBinding binding;
    LoginViewModel loginViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Eyes.translucentStatusBar(this);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_login);

        loginViewModel = new LoginViewModel(this,binding);
        binding.setLogin(loginViewModel);
    }
}
