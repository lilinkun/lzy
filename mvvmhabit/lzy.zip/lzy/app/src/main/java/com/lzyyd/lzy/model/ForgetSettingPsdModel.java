package com.lzyyd.lzy.model;

import android.content.Context;

import com.lzyyd.lzy.databinding.ActivityForgetSettingPsdBinding;

public class ForgetSettingPsdModel {


}
