package com.lzyyd.lzy.activity;

import android.graphics.Color;
import android.os.Bundle;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.adapter.SeckillAdapter;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.bean.SeckillGoodsBean;
import com.lzyyd.lzy.databinding.ActivitySeckillBinding;
import com.lzyyd.lzy.util.Eyes;
import com.lzyyd.lzy.viewmodel.SeckillViewModel;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SeckillActivity extends BaseActivity {

    private ActivitySeckillBinding seckillBinding;
    private SeckillViewModel seckillViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Eyes.setStatusBarColor1(this, Color.parseColor("#FF3C38"));

        seckillBinding = DataBindingUtil.setContentView(this, R.layout.activity_seckill);
        seckillViewModel = new SeckillViewModel(seckillBinding,this);
        seckillBinding.setSeckillviewmodel(seckillViewModel);

        initView();

    }


    public void initView(){

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);

        SeckillAdapter seckillAdapter = new SeckillAdapter(this);
        seckillAdapter.getItems().add(new SeckillGoodsBean("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/" +
                "it/u=1338127215,2214734562&fm=26&gp=0.jpg","adsadsasdads","2020-07-08 11:11:11",60));
        seckillAdapter.getItems().add(new SeckillGoodsBean("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/" +
                "it/u=1338127215,2214734562&fm=26&gp=0.jpg","adsadsasdads","2020-07-08 11:11:11",60));
        seckillAdapter.getItems().add(new SeckillGoodsBean("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/" +
                "it/u=1338127215,2214734562&fm=26&gp=0.jpg","adsadsasdads","2020-07-08 11:11:11",60));


        RecyclerView recyclerView = seckillBinding.recyclerSeckill;

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(seckillAdapter);

    }

}
