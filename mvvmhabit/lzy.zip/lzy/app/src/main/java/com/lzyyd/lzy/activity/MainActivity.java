package com.lzyyd.lzy.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.bean.User;
import com.lzyyd.lzy.databinding.ActivityMainBinding;
import com.lzyyd.lzy.viewmodel.MVVMViewModel;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    private MVVMViewModel mvvmViewModel;

    User user = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        MainActivityBindin
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main);

        mvvmViewModel = new MVVMViewModel(getApplication(),binding);
        binding.setViewModel(mvvmViewModel);  //初始化viewModel
    }
}
