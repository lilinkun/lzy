package com.lzyyd.lzy.bean;


import androidx.databinding.ObservableField;

public class User {

    public ObservableField<String> stringObservable =new ObservableField<>();

}
