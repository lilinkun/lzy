package com.lzyyd.lzy.activity;

import android.os.Bundle;
import android.widget.CompoundButton;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.databinding.ActivityForgetSettingPsdBinding;
import com.lzyyd.lzy.viewmodel.ForgetSettingPsdViewModel;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.InverseBindingMethod;
import androidx.databinding.InverseBindingMethods;

public class ForgetSettingPsdActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityForgetSettingPsdBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_forget_setting_psd);

        ForgetSettingPsdViewModel settingPsdViewModel = new ForgetSettingPsdViewModel(this,binding);

        binding.setForgetpsd(settingPsdViewModel);

//        binding.setVariable()
    }


}
