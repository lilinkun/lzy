package com.lzyyd.lzy.http;

/**
 * Created by LG on 2018/11/7.
 */

public interface RetrofitService {

//    @FormUrlEncoded
//    @POST("LoginDateServlet")
//    Observable<HashMap<String,String>> setTest(@FieldMap Map<String, String> map);




}
