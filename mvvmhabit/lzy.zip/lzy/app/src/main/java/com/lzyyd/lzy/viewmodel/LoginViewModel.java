package com.lzyyd.lzy.viewmodel;

import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.View;

import com.lzyyd.lzy.activity.ForgetPasswordActivity;
import com.lzyyd.lzy.activity.MainActivity;
import com.lzyyd.lzy.activity.RegisterActivity;
import com.lzyyd.lzy.activity.SeckillActivity;
import com.lzyyd.lzy.databinding.ActivityLoginBinding;
import com.lzyyd.lzy.model.LoginModel;

import androidx.databinding.BaseObservable;

public class LoginViewModel extends BaseObservable {

    ActivityLoginBinding binding;
    Context context;
    LoginModel loginModel;

    public LoginViewModel(Context context,ActivityLoginBinding binding) {
        this.binding = binding;
        this.context = context;
        loginModel = new LoginModel();
    }

    public void register(View view){

        Intent intent = new Intent(context, RegisterActivity.class);
        context.startActivity(intent);

    }

    public void forgetPsd(View view){

        Intent intent = new Intent(context, ForgetPasswordActivity.class);
        context.startActivity(intent);

    }

    public void login(View view){
        Intent intent = new Intent(context, MainActivity.class);
        context.startActivity(intent);
    }


    public void seckill(View view){

        Intent intent = new Intent(context, SeckillActivity.class);
        context.startActivity(intent);

    }


    public void setChecked(boolean isCheck){

        binding.etInputVcode.setInputType(isCheck ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);

    }

}
