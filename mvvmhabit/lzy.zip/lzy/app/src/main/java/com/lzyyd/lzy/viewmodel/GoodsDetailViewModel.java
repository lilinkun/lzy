package com.lzyyd.lzy.viewmodel;

import androidx.databinding.BaseObservable;

public class GoodsDetailViewModel extends BaseObservable {
}
