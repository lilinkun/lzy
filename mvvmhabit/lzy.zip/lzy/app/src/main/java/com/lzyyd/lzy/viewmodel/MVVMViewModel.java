package com.lzyyd.lzy.viewmodel;

import android.app.Application;
import android.view.View;

import com.lzyyd.lzy.BR;
import com.lzyyd.lzy.bean.Account;
import com.lzyyd.lzy.databinding.ActivityMainBinding;
import com.lzyyd.lzy.interf.MCallback;
import com.lzyyd.lzy.model.MVVMModel;

import java.util.Observable;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;

public class MVVMViewModel extends BaseObservable {

    private ActivityMainBinding binding;
    private MVVMModel mvvmModel;
    private String Input;
    private String result;

    @Bindable
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
        notifyPropertyChanged(BR.result);
    }
    //    一般需要传入Application对象，方便在ViewModel中使用application
    //    比如sharedpreferences需要使用
    public MVVMViewModel(Application application, ActivityMainBinding binding) {
        this.binding=binding;
        mvvmModel = new MVVMModel();

    }

    public void getData(View view){

    }
}
