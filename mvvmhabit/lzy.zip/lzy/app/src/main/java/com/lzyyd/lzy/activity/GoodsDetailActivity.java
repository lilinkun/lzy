package com.lzyyd.lzy.activity;

import android.database.DatabaseUtils;
import android.graphics.Color;
import android.os.Bundle;

import com.lzyyd.lzy.R;
import com.lzyyd.lzy.base.BaseActivity;
import com.lzyyd.lzy.databinding.ActivityGoodsDetailBinding;
import com.lzyyd.lzy.util.Eyes;
import com.lzyyd.lzy.util.TextUtil;
import com.lzyyd.lzy.viewmodel.GoodsDetailViewModel;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

public class GoodsDetailActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Eyes.translucentStatusBar(this);

        ActivityGoodsDetailBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_goods_detail);
        GoodsDetailViewModel  goodsDetailViewModel = new GoodsDetailViewModel();

        TextUtil.setText(this,"[预售] HFP低聚糖保湿乳液 清爽不 油腻水乳滋润补水面霜能量乳护肤品男女","秒杀",binding.tvGoodsContent);

    }
}
